﻿using System;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class frmPcalc : Form
    {
        public double numero1;
        public double numero2;
        public double resultado;

        public frmPcalc()
        {
            InitializeComponent();           
            this.btnLimpar.CausesValidation = false;
            this.btnSair.CausesValidation = false;
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            tbxResult.Text = resultado.ToString();
        }

        private void btnSubtrai_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            tbxResult.Text = resultado.ToString();
        }

        private void btnMultiplica_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            tbxResult.Text = resultado.ToString();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Número 2 deve ser diferente de 0");
                tbxNum2.Text = string.Empty;
                tbxNum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                tbxResult.Text = resultado.ToString();
            }            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            tbxNum1.Text = string.Empty;
            tbxNum2.Text = string.Empty;
            tbxResult.Text = string.Empty;
            tbxNum1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {            
            Application.Exit();
        }

        private void tbxNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(tbxNum1.Text, out numero1))
            {
                MessageBox.Show("Número 1 é inválido");
                tbxNum1.Text = string.Empty;
                tbxNum1.Focus();
            }
        }

        private void tbxNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(tbxNum2.Text, out numero2))
            {
                MessageBox.Show("Número 2 é inválido");
                tbxNum2.Text = string.Empty;
                tbxNum2.Focus();
            }
        }
    }
}
