﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmTriangulo
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblA = New System.Windows.Forms.Label()
        Me.lblB = New System.Windows.Forms.Label()
        Me.lblC = New System.Windows.Forms.Label()
        Me.txtA = New System.Windows.Forms.TextBox()
        Me.txtB = New System.Windows.Forms.TextBox()
        Me.txtC = New System.Windows.Forms.TextBox()
        Me.btnExecuta = New System.Windows.Forms.Button()
        Me.btnSair = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblA
        '
        Me.lblA.AutoSize = True
        Me.lblA.Location = New System.Drawing.Point(71, 27)
        Me.lblA.Name = "lblA"
        Me.lblA.Size = New System.Drawing.Size(87, 20)
        Me.lblA.TabIndex = 0
        Me.lblA.Text = "Valor de A:"
        '
        'lblB
        '
        Me.lblB.AutoSize = True
        Me.lblB.Location = New System.Drawing.Point(71, 65)
        Me.lblB.Name = "lblB"
        Me.lblB.Size = New System.Drawing.Size(87, 20)
        Me.lblB.TabIndex = 1
        Me.lblB.Text = "Valor de B:"
        '
        'lblC
        '
        Me.lblC.AutoSize = True
        Me.lblC.Location = New System.Drawing.Point(71, 105)
        Me.lblC.Name = "lblC"
        Me.lblC.Size = New System.Drawing.Size(87, 20)
        Me.lblC.TabIndex = 2
        Me.lblC.Text = "Valor de C:"
        '
        'txtA
        '
        Me.txtA.Location = New System.Drawing.Point(164, 24)
        Me.txtA.Name = "txtA"
        Me.txtA.Size = New System.Drawing.Size(109, 26)
        Me.txtA.TabIndex = 3
        '
        'txtB
        '
        Me.txtB.Location = New System.Drawing.Point(164, 62)
        Me.txtB.Name = "txtB"
        Me.txtB.Size = New System.Drawing.Size(109, 26)
        Me.txtB.TabIndex = 4
        '
        'txtC
        '
        Me.txtC.Location = New System.Drawing.Point(164, 102)
        Me.txtC.Name = "txtC"
        Me.txtC.Size = New System.Drawing.Size(109, 26)
        Me.txtC.TabIndex = 5
        '
        'btnExecuta
        '
        Me.btnExecuta.Location = New System.Drawing.Point(47, 151)
        Me.btnExecuta.Name = "btnExecuta"
        Me.btnExecuta.Size = New System.Drawing.Size(109, 55)
        Me.btnExecuta.TabIndex = 6
        Me.btnExecuta.Text = "Executa"
        Me.btnExecuta.UseVisualStyleBackColor = True
        '
        'btnSair
        '
        Me.btnSair.Location = New System.Drawing.Point(164, 151)
        Me.btnSair.Name = "btnSair"
        Me.btnSair.Size = New System.Drawing.Size(109, 55)
        Me.btnSair.TabIndex = 7
        Me.btnSair.Text = "Sair"
        Me.btnSair.UseVisualStyleBackColor = True
        '
        'frmTriangulo
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(350, 232)
        Me.Controls.Add(Me.btnSair)
        Me.Controls.Add(Me.btnExecuta)
        Me.Controls.Add(Me.txtC)
        Me.Controls.Add(Me.txtB)
        Me.Controls.Add(Me.txtA)
        Me.Controls.Add(Me.lblC)
        Me.Controls.Add(Me.lblB)
        Me.Controls.Add(Me.lblA)
        Me.Name = "frmTriangulo"
        Me.Text = "Tipo de Triângulo"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblA As Label
    Friend WithEvents lblB As Label
    Friend WithEvents lblC As Label
    Friend WithEvents txtA As TextBox
    Friend WithEvents txtB As TextBox
    Friend WithEvents txtC As TextBox
    Friend WithEvents btnExecuta As Button
    Friend WithEvents btnSair As Button
End Class
