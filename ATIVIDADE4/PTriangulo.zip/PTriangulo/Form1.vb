﻿Public Class frmTriangulo

    Public a, b, c As Double

    Private Sub btnExecuta_Click(sender As Object, e As EventArgs) Handles btnExecuta.Click

        If Double.TryParse(txtA.Text, a) And Double.TryParse(txtB.Text, b) And Double.TryParse(txtC.Text, c) Then
            If a + b > c And a + c > b And b + c > a Then
                If a = b And b = c Then
                    MessageBox.Show("Equilátero")
                ElseIf a = b Or a = c Or b = c Then
                    MessageBox.Show("Isósceles")
                Else
                    MessageBox.Show("Escaleno")
                End If
            Else
                MessageBox.Show("Os valores não formam um triângulo.")
            End If
        Else
            MessageBox.Show("Insira valores numéricos válidos.")
        End If
    End Sub

    Private Sub btnSair_Click(sender As Object, e As EventArgs) Handles btnSair.Click
        Application.Exit()
    End Sub
End Class
