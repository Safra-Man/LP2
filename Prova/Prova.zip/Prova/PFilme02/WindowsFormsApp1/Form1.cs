﻿using System;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class PFilme02 : Form
    {
        public PFilme02()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstBxResultado.Items.Clear();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[,] filmes = new double[2, 2];
            string entrada;
            double saida;

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    entrada = Interaction.InputBox($"Digite a nota do Filme {j + 1}:", $"Notas - Pessoa {i + 1}");
                    if (!double.TryParse(entrada, out saida) || saida < 0 || saida > 10)
                    {
                        MessageBox.Show("Valor Inválido!");
                        j--;
                    }
                    else
                    {
                        filmes[i, j] = Math.Round(saida, 2);
                    }
                }
            }

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    lstBxResultado.Items.Add($"Pessoa {i + 1} - Nota Filme {j + 1}: {filmes[i, j]}\n");
                }

            }

            double media1 = 0;
            double media2 = 0;

            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    if (j == 0) media1 += filmes[i, j];
                    if (j == 1) media2 += filmes[i, j];
                }

            }
            lstBxResultado.Items.Add("*************************");
            lstBxResultado.Items.Add($"Média Filme 1: {Math.Round(media1 / 2, 2)} | Média Filme 2: {Math.Round(media2 / 2, 2)}");
        }

    }

}
