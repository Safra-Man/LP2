﻿using System;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5 : Form
    {
        public int v1;
        public int v2;
        public int sort;
        public frmExercicio5()
        {
            InitializeComponent();

        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if (v2 < v1)
            {
                Random ObjV = new Random();
                sort = ObjV.Next(v2, v1);
            }
            else
            {
                Random ObjV = new Random();
                sort = ObjV.Next(v1, v2);
            }
            MessageBox.Show("O número sorteado é: " + sort);
        }

        private void txtValor1_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtValor1.Text, out v1))
            {
                MessageBox.Show("Valor 1 deve ser Inteiro!");
                txtValor1.Clear();
                txtValor1.Focus();
            }
        }

        private void txtValor2_Validated(object sender, EventArgs e)
        {
            if (!int.TryParse(txtValor2.Text, out v2))
            {
                MessageBox.Show("Valor 2 deve ser Inteiro!");
                txtValor2.Clear();
                txtValor2.Focus();
            }
        }
    }
}
