﻿using System;
using System.Windows.Forms;

namespace Ptestemetodos
{

    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int contaNum = 0;
            int contador = 0;

            while (contador < rchtxtTexto.Text.Length)
            {
                if (char.IsNumber(rchtxtTexto.Text[contador]))
                {
                    contaNum++;
                }
                contador++;
            }
            MessageBox.Show("Quantidade de números é: " + contaNum);
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            for (int i = 0; i < rchtxtTexto.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtTexto.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }

            }
            MessageBox.Show("A posição do primeiro caractere em branco é: " + posicao);
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (var c in rchtxtTexto.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }
            MessageBox.Show("Quantidade de Letras é igual a: " + contaLetra);
        }
    }
}
