﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio2 : Form
    {
        public string palavra1;
        public string palavra2;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnIguais_Click(object sender, EventArgs e)
        {
            if(txtPalavra1.Text == txtPalavra2.Text)
            {
                MessageBox.Show("As palavras são iguais!");
            }
            else
            {
                MessageBox.Show("As palavras são diferentes!");
            }
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            palavra1 = txtPalavra1.Text.ToString();
            palavra2 = txtPalavra2.Text.ToString();

            if (string.IsNullOrEmpty(palavra1) || string.IsNullOrEmpty(palavra2))
            {
                MessageBox.Show("Não podem existir valores vazios!");
                return;
            }

            int meio = palavra2.Length / 2; 
            string resultado = palavra2.Insert(meio, palavra1); 

            txtPalavra2.Text = resultado;
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            string palavra1 = txtPalavra1.Text;

            if (string.IsNullOrEmpty(palavra1))
            {
                MessageBox.Show("Palavra 1 não pode ser vazio!");
                return;
            }

            int meio = palavra1.Length / 2; 
            string resultado = palavra1.Insert(meio, "**");

            txtPalavra1.Text = resultado;
        }
    }
}
