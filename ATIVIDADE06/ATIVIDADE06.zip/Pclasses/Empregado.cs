﻿using System;

namespace Pclasses
{
    abstract internal class Empregado // a classe deve ser abstrata, não pode criar objetos a partir dela, ou horista ou mensalista. Temos metodos abstratos na classe também. 
    {
        private int matricula; // atributo
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula // propriedade
        {
            get { return matricula; } // a propriedade matricula esta vinculada ao atributo
            set { matricula = value; } // da para fazer validaçao no set
        }

        public DateTime DataEntradaEmpresa
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }

        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }
        // virtual: metodo com o mesmo nome em outras classes herdadas que pode ser sobreescrito. Se quiser matar e fazer outro pode.
        public virtual int TempoTrabalho()
        {
            TimeSpan span = DateTime.Today.Subtract(DataEntradaEmpresa);
            return (span.Days);
        }

        // abstract: ele não tem nehum codigo na classe pai, na classe filha é obrigada a declarar o salario bruto. 
        public abstract double SalarioBruto();
    
        public Empregado() //CONSTRUCTOR    
        {
            System.Windows.Forms.MessageBox.Show("Aqui é Empregado");
        }
    }
}
