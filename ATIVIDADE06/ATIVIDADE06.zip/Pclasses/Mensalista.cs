﻿using System;

namespace Pclasses
{
    internal class Mensalista : Empregado
    {
        public Double SalarioMensal { get; set; } // digitar prop tab tab cria uma propriedade genérica

        // sobrescrevendo o método

        public override double SalarioBruto()
        {
            return SalarioMensal;
        }

        //CTOR < Cria template , atalho para construtor
        public Mensalista()
        {
            System.Windows.Forms.MessageBox.Show("Aqui é Mensalista");
        }

        public Mensalista(int matx, string nomex, DateTime datax, double salx) // Sobrecarga - Mais de um construtor com diferentes parâmetros (Assinatura), ele escolhe de acordo com os parametros que chama. 
        {
            this.NomeEmpregado = nomex;
            this.Matricula = matx;
            this.DataEntradaEmpresa = datax;
            this.SalarioMensal = salx;            
        }

        public static string empresa = "Empresa LTDA.";

    }



}
