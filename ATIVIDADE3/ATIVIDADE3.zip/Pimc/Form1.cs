﻿using System;
using System.Windows.Forms;

namespace Pimc
{
    public partial class frmIMC : Form
    {
        public double peso=0;
        public double altura=0;
        public double imc;

        public frmIMC()
        {
            InitializeComponent();
            this.btnLimpar.CausesValidation = false;
            this.btnSair.CausesValidation = false;
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Peso Inválido!");
                mskbxPeso.Clear();
                mskbxPeso.Focus();
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida!");
                mskbxAltura.Clear();
                mskbxAltura.Focus();
            }

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPeso.Clear();
            mskbxAltura.Clear();
            txtImc.Clear();
            mskbxPeso.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(peso==0 || altura==0)
            {
                MessageBox.Show("Dados devem ser diferentes de 0!");
                mskbxPeso.Focus();
            }
            else
            {
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc, 1);
                txtImc.Text = imc.ToString();

                if (imc < 18.5) MessageBox.Show("MAGREZA");
                else if (imc <= 24.9) MessageBox.Show("NORMAL");
                else if (imc <= 29.9) MessageBox.Show("SOBREPESO");
                else if (imc <= 39.9) MessageBox.Show("OBESIDADE");
                else MessageBox.Show("OBESIDADE GRAVE");
            }
        }
    }
}

